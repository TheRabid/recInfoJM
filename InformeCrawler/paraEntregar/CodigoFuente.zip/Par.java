package prac4;

public class Par {

	public String docName;
	public String content;
	
	public Par(String d, String c){
		docName = d;
		content = c;
	}
}
